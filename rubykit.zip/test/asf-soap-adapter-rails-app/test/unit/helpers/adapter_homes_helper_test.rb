require 'test_helper'

class AdapterHomesHelperTest < ActionView::TestCase
end
