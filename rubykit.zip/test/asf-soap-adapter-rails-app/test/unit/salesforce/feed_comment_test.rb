require 'test_helper'

class Salesforce::FeedCommentTest < ActiveSupport::TestCase
  # Replace this with your real tests.
  # Cannot query 'FeedComment' directly
  test "the truth" do
    assert true
  end
end
