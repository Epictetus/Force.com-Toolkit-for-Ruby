require 'test_helper'

class Salesforce::FeedPostTest < ActiveSupport::TestCase
  # Replace this with your real tests.
  # Cannot query 'FeedPost' directly
  test "the truth" do
    assert true
  end
 
end
