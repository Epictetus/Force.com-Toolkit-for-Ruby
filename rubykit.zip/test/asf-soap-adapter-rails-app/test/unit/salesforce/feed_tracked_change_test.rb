require 'test_helper'

class Salesforce::FeedTrackedChangeTest < ActiveSupport::TestCase
  # Replace this with your real tests.
  #TODO cannot query 'FeedTrackedChange' directly
  test "the truth" do
    assert true
  end
end
