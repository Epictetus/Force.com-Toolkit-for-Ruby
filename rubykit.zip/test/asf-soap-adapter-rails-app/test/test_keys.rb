# This file contains password, security token, and userid for testing RForce only
USERID ='<userid in email form>'
SECURITY_TOKEN ='<security_token>'
PASSWORD ='<password>'