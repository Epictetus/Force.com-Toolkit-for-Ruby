class AdapterHome < ActiveRecord::Base
end
