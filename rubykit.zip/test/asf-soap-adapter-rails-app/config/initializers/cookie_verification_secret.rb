# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.cookie_verifier_secret = 'c6913bff1008242dc86a59234b50c61c70171e099a14bcae54721cfcbf32b179d591ba1b7d08da43451f44116589cec4db6320fa4c4a65dd5c3ec769d91f5361';
